
import React from 'react'
import axios from 'axios'
import { useDispatch } from 'react-redux'
import { useSelector } from 'react-redux'
import { toggleFollow } from '../redux/userSlice'
import { serverUrl } from '../App'

function FollowButton({targetUserId,tailwind,onFollowChange}) {
    const {following}=useSelector(state=>state.user)
    const isFollowing=following?.includes(targetUserId)

    const dispatch=useDispatch()
    const handleFollow=async()=>{
        try{
            // console.log("handlefollowe called in frontend", targetUserId)
            const result=await axios.get(`${serverUrl}/api/user/follow/${targetUserId}`,{withCredentials:true})
            // console.log("result in handleFollow in frontend after call: ", result.data);
            if(onFollowChange){
                console.log("onFollowChange called in frontend")
                onFollowChange()
            }
            dispatch(toggleFollow(targetUserId))
        }catch(error){
            console.log(error)
        }
    }
  return (
    <button className={tailwind} onClick={handleFollow}>
        {isFollowing?"Unfollow":"Follow"}
    </button>
  )
}

export default FollowButton