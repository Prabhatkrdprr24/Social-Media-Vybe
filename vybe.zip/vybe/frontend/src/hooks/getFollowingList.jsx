import axios from "axios";
import React from "react";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { setFollowing } from "../redux/userSlice";
import {serverUrl} from '../App.jsx'
import { useSelector } from "react-redux";

function getFollowingList() {

const dispatch = useDispatch();
const {storyData}=useSelector(state=>state.story)
  useEffect(() => {
    const fetchUser = async () => {
      try {
        console.log("get current user called at frontend");
        const result = await axios.get(`${serverUrl}/api/user/followingList`, {
          withCredentials: true,
        });
        // const res = await
        // dispatch(setUserData(result.json().data))
        console.log("Current User frontend", result);
        dispatch(setFollowing(result.data.following))

      } catch (error) {
        console.log(error);
      }
    };
    fetchUser();
  }, [storyData]);
}

export default getFollowingList;
